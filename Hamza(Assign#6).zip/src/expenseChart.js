// import { useState } from "react";

const expenseChart = (props)=>
{
    return(
        <div>
            
        </div>
    ); 
}

export default expenseChart;